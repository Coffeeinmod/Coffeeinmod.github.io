Coffeein Mod — Dismemberment (runtime only)

Csak a futtatáshoz kellő fájlok (nem a teljes projekt / forráskód).

Telepítés (GTA V gyökérbe másold):
1. Kell: Script Hook V (Blade) — http://www.dev-c.com/gtav/scripthookv/
2. Másold be a zip tartalmát a GTA V mappába (DismembermentASI.asi, ScriptHookVDotNet.*, scripts\, mods\).
3. OpenIV: mods/update/update.rpf → common/data/dlclist.xml
   Add: <Item>dlcpacks:\dismemberment\</Item>
4. Indítsd a játékot. Stable SHVDN v3.6.0 NEM elég — a pack Nightly-t tartalmaz (v3.7.0-nightly.177).

Tartalom:
- DismembermentASI.asi (tuned multi build)
- scripts/Dismemberment.dll + .toml + Weapons.cfg
- mods/.../dismemberment/dlc.rpf
- ScriptHookVDotNet Nightly (asi + dll + ini)

Kredit: CamxxCore (ASI), SpringBunny / Ze Krush (rpf tartalom), ScriptHookVDotNet team (Nightly).
