Coffeein Mod — Dismemberment (runtime)

Csak a mod működéséhez kellő fájlok.

Telepítés:
1. Script Hook V (Blade): http://www.dev-c.com/gtav/scripthookv/
2. SHVDN Nightly: https://github.com/scripthookvdotnet/scripthookvdotnet/wiki/Nightly-Builds
   (ScriptHookVDotNet.asi + ScriptHookVDotNet2/3.dll a GTA gyökérbe)
3. Zip tartalmát másold a GTA V gyökérbe
4. OpenIV: dlclist.xml → <Item>dlcpacks:\dismemberment\</Item>

Tartalom: DismembermentASI.asi, scripts\, mods\...\dlc.rpf
